from django.contrib import admin
from django.urls import path
from . import  views
urlpatterns = [
    path('sarah/home', views.index, name="index"), 
    path('', views.index, name="index"), 
    path('contact/', views.contact, name="contact"), 
    path('contact/contact/', views.contact, name="contact"), 
]